﻿using Epione.Data.Infrastructures;
using Epione.Domain.Entities;
using Service.Pattern;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Epione.Service
{
   public class GestionUser : GestionService<User>, IGestionUser
    {
          public static DatabaseFactory dbFactory = new DatabaseFactory();
          public static UnitOfWork utw = new UnitOfWork(dbFactory);


          public GestionUser() : base(utw)
          {

          }
        
    }
}
